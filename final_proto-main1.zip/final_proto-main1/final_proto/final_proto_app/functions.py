from urllib.parse import urlparse, parse_qs
from pprint import pprint
from google_auth_oauthlib.flow import Flow, InstalledAppFlow
from googleapiclient.discovery import build
from google.oauth2.credentials import Credentials
from allauth.socialaccount.models import SocialToken, SocialApp
from django.shortcuts import render, redirect
from django.http import HttpResponseRedirect, HttpResponse
from pytchat import LiveChat, CompatibleProcessor
from chat_downloader import ChatDownloader
import time
import pytchat
import subprocess
import shlex
import requests
from django.http import StreamingHttpResponse
from django.views.decorators.csrf import csrf_exempt
import json
import os
import signal
from google.oauth2 import service_account
import googleapiclient.discovery

subprocess_value = None


def extract_video_id(url):
    # Examples:
    # - http://youtu.be/SA2iWivDJiE
    # - http://www.youtube.com/watch?v=_oPAwA_Udwc&feature=feedu
    # - http://www.youtube.com/embed/SA2iWivDJiE
    # - http://www.youtube.com/v/SA2iWivDJiE?version=3&amp;hl=en_US
    query = urlparse(url)
    if query.hostname == 'youtu.be': return query.path[1:]
    if query.hostname in {'www.youtube.com', 'youtube.com'}:
        if query.path == '/watch': return parse_qs(query.query)['v'][0]
        if query.path[:7] == '/embed/': return query.path.split('/')[2]
        if query.path[:3] == '/v/': return query.path.split('/')[2]
    print(query)
    # fail?
    return None


def check_active_livechat(url, request):
    print(type(request.user))
    id = extract_video_id(url)
    print("HIII")
    print(id)
    '''token = SocialToken.objects.get(account__user=request.user, account__provider='google')
    print(token)
    # CLIENT_SECRET_FILE = 'client_secret_51870834106-rtq1bi2n4n6cme450auv0iffv9fpokre.apps.googleusercontent.com.json'
    # flow = InstalledAppFlow.from_client_secrets_file(CLIENT_SECRET_FILE, SCOPES)
    credentials = Credentials(
        token=token.token,
        refresh_token=token.token_secret,
        token_uri='https://oauth2.googleapis.com/token',
        client_id='1029206427857-h1b7u14uco111f4067kn27ac729uhfhs.apps.googleusercontent.com', # replace with yours
        client_secret='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') # replace with yours
    print("secret token:"+ " "+credentials.refresh_token)
    service = build('youtube', 'v3', credentials=credentials)
    print(service)'''
    credentials_info = {
        "type": "service_account",
        "project_id": "crack-cogency-419915",
        "private_key_id": "0bf755edee5927381f9ccc88044221b00857724e",
        "private_key": "-----BEGIN PRIVATE KEY-----\nMIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQC06liZN3/HSSlo\noyPXzsx/KlBQYRkIHxZIdCVVVvXcw5o+ynjsv9r/lGw/fdavtAZrbxzoixVrwK+a\nU7H0ZjW01N173kBLxOYtIx8GDNO+8kXb/lvFXxYnSDOSv8lRGp0IcBcZsWFeWAAo\nBxZqWkD0AGLzD47xepU7+A+AR7mhY7ckkFcVL5VPmnvxpEGtx/tS1U9o5zNW20dn\nItpy+2nH0ssB0j7ttPyHHZ/w4rkOMPgQizcQf3gjOGJIVQh2nlgh0U/M6XZSaywl\nEaGMDUACy+KUfVSyS2+MctSIhE9lPXqjIBk1VNvOckjtH/pY9kv/kQDPTEml4I/F\nnWflTIz5AgMBAAECggEAMfcXCRne3HdETHXiDFQ8/lH9ZHWsqCWNzezl8q/Vr2cG\nTpk01I4YOcYQL2jdxiD+NOW3IjJndB7/YKwE1e70nkC7+t3i/AohWA3/H3ijcnUO\n/jc9uUENqUOzmrAFNbUX8aCjgKEQtzGuuV9bvXu3vKvuqBp/7Ali9fEItvEYP44H\nADCDXLLFWyYn9hmHqwvv7JCruG1EWwI9IlamzwUnnj6dekp1fwqDw39jFGH/z5ij\nHauOO4gD8VuVPG742No+0iXVNHebCEanmjRzIfnK7AQDXfCO9XGr/nJat9aWHDiq\nxmNB92m7FhDil5krJo17nxRj8VsFa+909kd3JYB9kQKBgQDw+jmno+mO8VCHAeMw\nbSaKqX+EyaPcIJ5vHBxLf+dd/6SwtOiV0tvHNDm4P5i+xfmVccF010lz7x1HxcOh\nG9TKw0Y+2LodaM5VvHkP3O8qGew1epVyb29xKhgInYC6RaAj63yMDx3ZpV92Usda\nx1QSWLDW4eYRnNha88OycbI+VwKBgQDAMZZIEEZHWGl7PbFfCMwOKHMmUGJVHV1f\njgNRQnP1jn++aRZ4fHCBcdk7ihFJhUEFaMc21ix2dvvWc1iyqGuknavVAkKz8Vbp\nvrOmPi56wa6/ddcuftHKOINJmIKCIZysjeomxKDEfzyttZ5XRT/BMlTykpyat1Nw\nFdjXCw7dLwKBgQDAsugd5VZkhxYlD95UIEScx5QAZJpS8gafxTPfMAWdRku1PsVq\n4bX8IwgxDTIhBAFkfxX7UBkdy0130m5wy+eqyOLIaNjToba2GsQYak0aNqaL0V3m\np7PPI6EaapDA4+J+NtZezcvJ+pNO9D0Um6bgEOpAu14WIX1lpd6NOJwXewKBgHsb\niDKy0gGDPVWmx8WjAeoTuOaS2NnCTHwXoEJduZ9R3rud3rngo8QWo9pCbx5Tz7li\nSzDx8VsUje3oxqjxvrmcEWQI5acTcOOatsJG1EjnZULYfbQXodPRbS8oFHi8hPn2\nkUSx8HTNN5XhXwJxpgvfbJBQnyVvRm/mXpYoTCYbAoGAD7iG7A2aD1uuJVe8sxFf\nAsURhv/ctGOguneXNIKFOFztm2gpeEqoQ4tfM7qREJuHiqpqPov0evKVYq/lMrk7\nUkEtpkEuEVwXjwKmw6sXJ9i+gx2NnwCZ544YDEe28bddIwbmB8IyE4gWv2IbreZF\nUwF+y0AoWyS48q0oqyKzyOw=\n-----END PRIVATE KEY-----\n",
        "client_email": "firebase-adminsdk-2r4ny@crack-cogency-419915.iam.gserviceaccount.com",
        "client_id": "118420008483487538314",
        "auth_uri": "https://accounts.google.com/o/oauth2/auth",
        "token_uri": "https://oauth2.googleapis.com/token",
        "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
        "client_x509_cert_url": "https://www.googleapis.com/robot/v1/metadata/x509/firebase-adminsdk-2r4ny%40crack-cogency-419915.iam.gserviceaccount.com",
        "universe_domain": "googleapis.com"
    }

    credentials = service_account.Credentials.from_service_account_info(
        credentials_info,
        scopes=['https://www.googleapis.com/auth/youtube']
    )

    # Create a YouTube Data API client
    youtube = googleapiclient.discovery.build('youtube', 'v3', credentials=credentials)

    # Example: Get information about a YouTube video
    print("HELLOOO")
    video_id = '9M02G5c6x6w'
    part_string = 'snippet,liveStreamingDetails'
    response = youtube.videos().list(
        part=part_string,
        id=video_id
    ).execute()

    # Print the video's title
    print("Video Title:", response['items'][0]['snippet']['title'])

    #video_ids = id
    # find data using API regarding video

    '''response = service.videos().list(
        part=part_string,
        id=video_ids
    ).execute()'''
    try:
        print(response['items'][0]['liveStreamingDetails']['activeLiveChatId'])
        livechatstatus = 'alive'
        return livechatstatus
    except:
        print("errrorrrrrr")
        livechatstatus = 'dead'
        return livechatstatus
    return livechatstatus


def send_message(request):
    data = json.loads(request.body.decode('UTF-8'))
    url = data['url']
    message = data['message']
    id = extract_video_id(url)
    print(id)
    '''token = SocialToken.objects.get(account__user=request.user, account__provider='google')
    print(token)
    # CLIENT_SECRET_FILE = 'client_secret_51870834106-rtq1bi2n4n6cme450auv0iffv9fpokre.apps.googleusercontent.com.json'
    # flow = InstalledAppFlow.from_client_secrets_file(CLIENT_SECRET_FILE, SCOPES)
    credentials = Credentials(
        token=token.token,
        refresh_token=token.token_secret,
        token_uri='https://oauth2.googleapis.com/token',
        client_id='375686044917-4ip2r585igrkf6kesp3ggmfd45f53433.apps.googleusercontent.com', # replace with yours 
        client_secret='HZgBiq-fG0_vrfsxHHNA7Ptu') # replace with yours 
    print("secret token:"+ " "+credentials.refresh_token)
    service = build('youtube', 'v3', credentials=credentials)
    print(service)
    

    part_string = 'snippet,liveStreamingDetails'
    video_ids = id
    #find data using API regarding video

    response = service.videos().list(
        part=part_string,
        id=video_ids
    ).execute()'''

    credentials_info = {
        "type": "service_account",
        "project_id": "crack-cogency-419915",
        "private_key_id": "0bf755edee5927381f9ccc88044221b00857724e",
        "private_key": "-----BEGIN PRIVATE KEY-----\nMIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQC06liZN3/HSSlo\noyPXzsx/KlBQYRkIHxZIdCVVVvXcw5o+ynjsv9r/lGw/fdavtAZrbxzoixVrwK+a\nU7H0ZjW01N173kBLxOYtIx8GDNO+8kXb/lvFXxYnSDOSv8lRGp0IcBcZsWFeWAAo\nBxZqWkD0AGLzD47xepU7+A+AR7mhY7ckkFcVL5VPmnvxpEGtx/tS1U9o5zNW20dn\nItpy+2nH0ssB0j7ttPyHHZ/w4rkOMPgQizcQf3gjOGJIVQh2nlgh0U/M6XZSaywl\nEaGMDUACy+KUfVSyS2+MctSIhE9lPXqjIBk1VNvOckjtH/pY9kv/kQDPTEml4I/F\nnWflTIz5AgMBAAECggEAMfcXCRne3HdETHXiDFQ8/lH9ZHWsqCWNzezl8q/Vr2cG\nTpk01I4YOcYQL2jdxiD+NOW3IjJndB7/YKwE1e70nkC7+t3i/AohWA3/H3ijcnUO\n/jc9uUENqUOzmrAFNbUX8aCjgKEQtzGuuV9bvXu3vKvuqBp/7Ali9fEItvEYP44H\nADCDXLLFWyYn9hmHqwvv7JCruG1EWwI9IlamzwUnnj6dekp1fwqDw39jFGH/z5ij\nHauOO4gD8VuVPG742No+0iXVNHebCEanmjRzIfnK7AQDXfCO9XGr/nJat9aWHDiq\nxmNB92m7FhDil5krJo17nxRj8VsFa+909kd3JYB9kQKBgQDw+jmno+mO8VCHAeMw\nbSaKqX+EyaPcIJ5vHBxLf+dd/6SwtOiV0tvHNDm4P5i+xfmVccF010lz7x1HxcOh\nG9TKw0Y+2LodaM5VvHkP3O8qGew1epVyb29xKhgInYC6RaAj63yMDx3ZpV92Usda\nx1QSWLDW4eYRnNha88OycbI+VwKBgQDAMZZIEEZHWGl7PbFfCMwOKHMmUGJVHV1f\njgNRQnP1jn++aRZ4fHCBcdk7ihFJhUEFaMc21ix2dvvWc1iyqGuknavVAkKz8Vbp\nvrOmPi56wa6/ddcuftHKOINJmIKCIZysjeomxKDEfzyttZ5XRT/BMlTykpyat1Nw\nFdjXCw7dLwKBgQDAsugd5VZkhxYlD95UIEScx5QAZJpS8gafxTPfMAWdRku1PsVq\n4bX8IwgxDTIhBAFkfxX7UBkdy0130m5wy+eqyOLIaNjToba2GsQYak0aNqaL0V3m\np7PPI6EaapDA4+J+NtZezcvJ+pNO9D0Um6bgEOpAu14WIX1lpd6NOJwXewKBgHsb\niDKy0gGDPVWmx8WjAeoTuOaS2NnCTHwXoEJduZ9R3rud3rngo8QWo9pCbx5Tz7li\nSzDx8VsUje3oxqjxvrmcEWQI5acTcOOatsJG1EjnZULYfbQXodPRbS8oFHi8hPn2\nkUSx8HTNN5XhXwJxpgvfbJBQnyVvRm/mXpYoTCYbAoGAD7iG7A2aD1uuJVe8sxFf\nAsURhv/ctGOguneXNIKFOFztm2gpeEqoQ4tfM7qREJuHiqpqPov0evKVYq/lMrk7\nUkEtpkEuEVwXjwKmw6sXJ9i+gx2NnwCZ544YDEe28bddIwbmB8IyE4gWv2IbreZF\nUwF+y0AoWyS48q0oqyKzyOw=\n-----END PRIVATE KEY-----\n",
        "client_email": "firebase-adminsdk-2r4ny@crack-cogency-419915.iam.gserviceaccount.com",
        "client_id": "118420008483487538314",
        "auth_uri": "https://accounts.google.com/o/oauth2/auth",
        "token_uri": "https://oauth2.googleapis.com/token",
        "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
        "client_x509_cert_url": "https://www.googleapis.com/robot/v1/metadata/x509/firebase-adminsdk-2r4ny%40crack-cogency-419915.iam.gserviceaccount.com",
        "universe_domain": "googleapis.com"
    }

    credentials = service_account.Credentials.from_service_account_info(
        credentials_info,
        scopes=['https://www.googleapis.com/auth/youtube']
    )

    # Create a YouTube Data API client
    youtube = googleapiclient.discovery.build('youtube', 'v3', credentials=credentials)

    # Example: Get information about a YouTube video
    print("HELLOOO")
    video_id = '9M02G5c6x6w'
    part_string = 'snippet,liveStreamingDetails'
    response = youtube.videos().list(
        part=part_string,
        id=video_id
    ).execute()

    # Print the video's title
    print("Video Title:", response['items'][0]['snippet']['title'])

    video_ids = id
    # find data using API regarding video

    # print(response)
    # #gets active livechat id and channelid
    channelid = response['items'][0]['snippet']['channelId']
    livechatid = response['items'][0]['liveStreamingDetails']['activeLiveChatId']
    # # print("this is the channel id: " + response['items'][0]['snippet']['channelId'])
    # # print("you are currently watching " + response['items'][0]['snippet']['title'] + " by: " + response['items'][0]['snippet']['channelTitle'])
    # if response['items'][0]['snippet']['liveBroadcastContent'] == 'none':
    #     print("hey this isnt a live stream, checking if this is an archive")
    #     chat = ChatDownloader().get_chat(url)       # create a generator
    #     for message in chat:
    #         print(chat.format(message))     
    #     return render(request, 'index.html')
    # else:

    # print("this is the livechat id: " + response['items'][0]['liveStreamingDetails']['activeLiveChatId'])
    # prints out all live chat messages
    # response1 = service.liveChatMessages().list(
    #         liveChatId = livechatid,
    #         part = 'snippet'
    #     ).execute()

    # print(response1)
    # sends out a message to the live chat
    response2 = service.liveChatMessages().insert(
        part='snippet',
        body=dict(
            snippet=dict(
                liveChatId=livechatid,
                type="textMessageEvent",
                textMessageDetails=dict(
                    messageText=message
                )
            )
        )
    ).execute()

    # print(response2)


def view_message(request):
    data = json.loads(request.body.decode('UTF-8'))
    print(data)
    url = data['url']
    token = data['token']
    print(url)
    print(data)
    function_call = 'python3 tester3.py ' + str(url) + " " + str(token)
    print("this is the function call " + function_call)
    # subprocess_value = subprocess.Popen(shlex.split('python3 tester3.py ' + str(url) +" "+ str(token)))

    print("is this weird")
    return HttpResponse("subprocess started")


def get_translated_messages(url, request):
    proc = subprocess.Popen(shlex.split('python3 tester4.py'))


def close_subprocess(request):
    print("yes this function is actually called")
    subprocess_value.terminate()


def translate_user_message(request):
    data1 = json.loads(request.body.decode('UTF-8'))
    url = 'http://localhost:5000/translate_send'
    data = {
        "message": data1['message'],
    }
    response = requests.post(url, json=data)
    response_tet = "succees call"
    return None

def print_message(request,message):
    return render(request, '500.html', message)

@csrf_exempt
def display_text(request):
    content = open('chatlist.txt', 'r').readline()
    response = StreamingHttpResponse(content)
    response['Content-Type'] = 'text/plain; charset=utf8'
    #return response
    print(response)

    credentials_info = {
        "type": "service_account",
        "project_id": "crack-cogency-419915",
        "private_key_id": "0bf755edee5927381f9ccc88044221b00857724e",
        "private_key": "-----BEGIN PRIVATE KEY-----\nMIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQC06liZN3/HSSlo\noyPXzsx/KlBQYRkIHxZIdCVVVvXcw5o+ynjsv9r/lGw/fdavtAZrbxzoixVrwK+a\nU7H0ZjW01N173kBLxOYtIx8GDNO+8kXb/lvFXxYnSDOSv8lRGp0IcBcZsWFeWAAo\nBxZqWkD0AGLzD47xepU7+A+AR7mhY7ckkFcVL5VPmnvxpEGtx/tS1U9o5zNW20dn\nItpy+2nH0ssB0j7ttPyHHZ/w4rkOMPgQizcQf3gjOGJIVQh2nlgh0U/M6XZSaywl\nEaGMDUACy+KUfVSyS2+MctSIhE9lPXqjIBk1VNvOckjtH/pY9kv/kQDPTEml4I/F\nnWflTIz5AgMBAAECggEAMfcXCRne3HdETHXiDFQ8/lH9ZHWsqCWNzezl8q/Vr2cG\nTpk01I4YOcYQL2jdxiD+NOW3IjJndB7/YKwE1e70nkC7+t3i/AohWA3/H3ijcnUO\n/jc9uUENqUOzmrAFNbUX8aCjgKEQtzGuuV9bvXu3vKvuqBp/7Ali9fEItvEYP44H\nADCDXLLFWyYn9hmHqwvv7JCruG1EWwI9IlamzwUnnj6dekp1fwqDw39jFGH/z5ij\nHauOO4gD8VuVPG742No+0iXVNHebCEanmjRzIfnK7AQDXfCO9XGr/nJat9aWHDiq\nxmNB92m7FhDil5krJo17nxRj8VsFa+909kd3JYB9kQKBgQDw+jmno+mO8VCHAeMw\nbSaKqX+EyaPcIJ5vHBxLf+dd/6SwtOiV0tvHNDm4P5i+xfmVccF010lz7x1HxcOh\nG9TKw0Y+2LodaM5VvHkP3O8qGew1epVyb29xKhgInYC6RaAj63yMDx3ZpV92Usda\nx1QSWLDW4eYRnNha88OycbI+VwKBgQDAMZZIEEZHWGl7PbFfCMwOKHMmUGJVHV1f\njgNRQnP1jn++aRZ4fHCBcdk7ihFJhUEFaMc21ix2dvvWc1iyqGuknavVAkKz8Vbp\nvrOmPi56wa6/ddcuftHKOINJmIKCIZysjeomxKDEfzyttZ5XRT/BMlTykpyat1Nw\nFdjXCw7dLwKBgQDAsugd5VZkhxYlD95UIEScx5QAZJpS8gafxTPfMAWdRku1PsVq\n4bX8IwgxDTIhBAFkfxX7UBkdy0130m5wy+eqyOLIaNjToba2GsQYak0aNqaL0V3m\np7PPI6EaapDA4+J+NtZezcvJ+pNO9D0Um6bgEOpAu14WIX1lpd6NOJwXewKBgHsb\niDKy0gGDPVWmx8WjAeoTuOaS2NnCTHwXoEJduZ9R3rud3rngo8QWo9pCbx5Tz7li\nSzDx8VsUje3oxqjxvrmcEWQI5acTcOOatsJG1EjnZULYfbQXodPRbS8oFHi8hPn2\nkUSx8HTNN5XhXwJxpgvfbJBQnyVvRm/mXpYoTCYbAoGAD7iG7A2aD1uuJVe8sxFf\nAsURhv/ctGOguneXNIKFOFztm2gpeEqoQ4tfM7qREJuHiqpqPov0evKVYq/lMrk7\nUkEtpkEuEVwXjwKmw6sXJ9i+gx2NnwCZ544YDEe28bddIwbmB8IyE4gWv2IbreZF\nUwF+y0AoWyS48q0oqyKzyOw=\n-----END PRIVATE KEY-----\n",
        "client_email": "firebase-adminsdk-2r4ny@crack-cogency-419915.iam.gserviceaccount.com",
        "client_id": "118420008483487538314",
        "auth_uri": "https://accounts.google.com/o/oauth2/auth",
        "token_uri": "https://oauth2.googleapis.com/token",
        "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
        "client_x509_cert_url": "https://www.googleapis.com/robot/v1/metadata/x509/firebase-adminsdk-2r4ny%40crack-cogency-419915.iam.gserviceaccount.com",
        "universe_domain": "googleapis.com"
    }

    credentials = service_account.Credentials.from_service_account_info(
        credentials_info,
        scopes=['https://www.googleapis.com/auth/youtube']
    )

    # Create a YouTube Data API client
    service = googleapiclient.discovery.build('youtube', 'v3', credentials=credentials)

    # Example: Get information about a YouTube video
    print("HELLOOO")
    video_id = '9M02G5c6x6w'
    part_string = 'snippet,liveStreamingDetails'
    response = service.videos().list(
        part=part_string,
        id=video_id
    ).execute()

    #gets active livechat id and channelid
    channelid = response['items'][0]['snippet']['channelId']

    print("this is the channel id: " + response['items'][0]['snippet']['channelId'])
    print("you are currently watching " + response['items'][0]['snippet']['title'] + " by: " + response['items'][0]['snippet']['channelTitle'])

    if response['items'][0]['snippet']['liveBroadcastContent'] == 'none':
        print("hey this isnt a live stream, checking if this is an archive")
        chat = ChatDownloader().get_chat("https://www.youtube.com/watch?v=9M02G5c6x6w")  # create a generator
        for message in chat:
            print(chat.format(message))
            context = {'message': chat.format(message)}
            print_message(request, context)
    else:
        livechatid = response['items'][0]['liveStreamingDetails']['activeLiveChatId']

    print("this is the livechat id: " + response['items'][0]['liveStreamingDetails']['activeLiveChatId'])

    response1 = service.liveChatMessages().list(
        liveChatId=livechatid,
        part='snippet'
    ).execute()

    print(type(response1))
    print(type(response1['items']))

    context1 = {}
    for i in range(len(response1['items'])):
        message = response1['items'][i]['snippet']['textMessageDetails']['messageText']
        response2 = service.channels().list(
            id=response1['items'][i]['snippet']['authorChannelId'],
            part='snippet'
        ).execute()
        author = response2['items'][0]['snippet']['title']
        context1['message_entry ' + str(i)] = {"author": author, 'message': message}

    context3 = []

    chat = ChatDownloader().get_chat("https://www.youtube.com/watch?v=9M02G5c6x6w")  # create a generator
    for message in chat:
        print(chat.format(message))
        context1 = {'message': chat.format(message)}

    # sends out a message to the live chat
    response2 = service.liveChatMessages().insert(
        part='snippet',
        body=dict(
            snippet=dict(
                liveChatId=livechatid,
                type="textMessageEvent",
                textMessageDetails=dict(
                    messageText=message
                )
            )
        )
    ).execute()

    print(response2)

    '''context = {
        'context1': context1,  # Assuming 'chat_messages' is your processed data
        'title': 'Your YouTube Video Title',  # Pass any relevant data needed in the template
    }

    # Render the template with the context data
    return render(request, '500.html', context1)'''

    #return response2