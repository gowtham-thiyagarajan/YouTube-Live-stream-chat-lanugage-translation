from django.apps import AppConfig


class FinalProtoAppConfig(AppConfig):
    name = 'final_proto_app'

