

//males formatting

do ai functionality

fix view send page ( in progress)

do proper video tutorial for url 

pause scroll (https://stackoverflow.com/questions/46269531/auto-scroll-down-but-stop-when-user-scrolls)

button to bottom of scroll(https://www.w3schools.com/howto/tryit.asp?filename=tryhow_js_scroll_to_top)

alert user if sent message, clear the textarea

tanya ci vero about the ui


testing site https://www.youtube.com/watch?v=5qap5aO4i9A